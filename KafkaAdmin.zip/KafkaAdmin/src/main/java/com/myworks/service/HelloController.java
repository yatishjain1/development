package com.myworks.service;

import java.util.Properties;
import java.util.Set;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.springframework.web.bind.annotation.*;

import com.myworks.ConfigUtils;

@RestController
@RequestMapping("list")
public class HelloController {


   /* @PostMapping(value = "/postItem",consumes = {"application/json"},produces = {"application/json"})
    public String postJsonMessage(@RequestBody Item item){
        //KafkaJsontemplate.send(TOPIC_NAME,new Item(1,"Lenovo","Laptop"));
    	KafkaJsontemplate.send(TOPIC_NAME,item);
        return "Message published successfully";
    }*/
	 @RequestMapping("/hello")
	    public String index() {
	        return "Greetings from Spring Boot!";
	    }
    
    @RequestMapping("/topics")
    public String listTopics() {
    	try {
			Properties prop = ConfigUtils.getConfiguration("admin-config");
			AdminClient admin = AdminClient.create(prop);
			ListTopicsResult topics = admin.listTopics();
			Set<String> topicNames = topics.names().get();
			for(String topic: topicNames) {
				System.out.println(topic);
			}
			return topicNames.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return "";
    }
}
